//
//  LocationViewController.swift
//  AppleCoreLocationAPIDemo
//
//  Created by Ani Adhikary on 25/03/20.
//  Copyright © 2020 TheTechStory. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps

class LocationViewController: UIViewController {
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var addressLabel: UILabel!
    
    var locationManager: CLLocationManager?
        
    override func viewDidLoad() {
        super.viewDidLoad()
        checkForLocationServices()
    }
    
    //Helper functions
    
    func setupLocation() {
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
    }
    
    func activateLocationServices() {
        locationManager?.requestLocation()
    }
    
    func reverseGeocode(coordinate: CLLocationCoordinate2D) {
        // 1
        let geocoder = GMSGeocoder()
        
        // 2
        geocoder.reverseGeocodeCoordinate(coordinate) { response, error in
            guard
                let address = response?.firstResult(),
                let lines = address.lines
                else {
                    return
            }
            
            // 3
            self.addressLabel.text = lines.joined(separator: "\n")
            
            // 4
            UIView.animate(withDuration: 0.25) {
                self.view.layoutIfNeeded()
            }
        }
    }
    
    func checkForLocationServices() {
        setupLocation()
        if CLLocationManager.locationServicesEnabled() {
            switch CLLocationManager.authorizationStatus() {
            case .notDetermined:
                print("No access - Not determined")
                locationManager?.requestWhenInUseAuthorization()
            case .denied:
                print("No access - Denied")
                //Go To Settings - show Alert
                showAlertForSettings()
            case .restricted:
                print("No access - Restricted")
            case .authorizedAlways, .authorizedWhenInUse:
                print("Access")
                activateLocationServices()
            default:
                break
            }
        }
    }
    
    func showAlertForSettings() {
        let alertController = UIAlertController(title: "HSBC would like to access your GPS", message: "To continue, please allow GPS access in Settings", preferredStyle: .alert)
        
        // Create OK button
        let openSettingsAction = UIAlertAction(title: "Open Settings", style: .default) { (action:UIAlertAction!) in
            
            // Code in this block will trigger when OK button tapped.
            print("Open Settings button tapped");
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
            } else {
                // Fallback on earlier versions
            }
            //UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
        }
        alertController.addAction(openSettingsAction)
        
        // Create Cancel button
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
            print("Cancel button tapped");
        }
        alertController.addAction(cancelAction)
        
        // Present Dialog message
        self.present(alertController, animated: true, completion:nil)
    }
    
}

extension LocationViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            print("Access provided by user")
            activateLocationServices() //called first time access happy flow
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        
        reverseGeocode(coordinate: locValue)
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
    }
}
