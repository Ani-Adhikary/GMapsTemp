//
//  Alert.swift
//  USAKneeCenters
//
//  Created by Anindita Adhikary on 02/04/18.
//

import Foundation
import UIKit

class Alert {
    
    class func showBasicAlert(title: String, message: String, vc: UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        vc.present(alert, animated: true)
    }
    
    class func showLogoffAlert(title: String, message: String, vc: UIViewController) {
    
        let messageToShow = NSLocalizedString("Are you sure \n you want to log off?", comment: "")
        let alertController = UIAlertController(title: "", message: "", preferredStyle: .alert)
        
        var msgMutableString = NSMutableAttributedString()
        msgMutableString = NSMutableAttributedString(string: messageToShow as String, attributes: [NSAttributedString.Key.font : UIFont(name: "Avenir-Light", size: 17.0)!])
        
        msgMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor(red: 37.0/255, green: 37.0/255, blue: 37.0/255, alpha: 1.0), range: NSRange(location: 0, length: messageToShow.count))
        
        alertController.setValue(msgMutableString, forKey: "attributedMessage")
        
        //let cancelBtn = NSLocalizedString("Cancel", comment: "")
        //let okBtn = NSLocalizedString("OK", comment: "")
        
        let exitAction = UIAlertAction(title: "Log off", style: .default) { (UIAlertAction) in
            self.onLogoffSuccess()
        }
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        alertController.addAction(exitAction)
        
        vc.present(alertController, animated: true)
        
    }
    
    class func onLogoffSuccess() {
        print("Logged off")
        //navigationController.popViewController(animated: true)
    }
}
