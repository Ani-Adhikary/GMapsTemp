//
//  AppDelegate.swift
//


import UIKit
import GoogleMaps

//1
let googleApiKey = "AIzaSyCl7g1oZq2FFWoqVjIFEUPYBmcjbIiEASQ"

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    //1
    //Declare Nav Controller
    let navigationController = UINavigationController()
    
    //1
    
    

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        GMSServices.provideAPIKey(googleApiKey)
        
        //2
        //set up window
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()
        //window?.frame = UIScreen.main.bounds
        setupNavigationController()
        setupUserInterface()
        return true
    }

    

    
    //3
    func setupNavigationController() {
        window?.rootViewController = navigationController
        let navBarAppearance = UINavigationBar.appearance()
        navBarAppearance.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        navBarAppearance.barTintColor = UIColor(red: 122.0/255, green: 129.0/255, blue: 255.0/255, alpha: 1.0)
    }
    
    //4
    func setupUserInterface() {
//        let loginVC = LoginViewController(nibName: "LoginViewController", bundle: nil)
//        navigationController.pushViewController(loginVC, animated: false)
        //or
        navigationController.pushViewController(LocationViewController(), animated: false)
    }
    
}

